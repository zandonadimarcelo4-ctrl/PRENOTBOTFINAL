import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

import main


class FakeOption:
    def __init__(self, text):
        self.text = text


class TestConfig(unittest.TestCase):
    def test_load_config_defaults(self):
        cfg = main.load_config()
        self.assertIn(cfg["request_type"], cfg["service_ids"])
        self.assertGreaterEqual(cfg["intervalo_min_segundos"], 20)

    def test_invalid_request_type(self):
        tmp = Path(main.BASE_DIR / "tests" / "_tmp.yaml")
        tmp.write_text('request_type: "xyz"\n', encoding="utf-8")
        try:
            with self.assertRaises(SystemExit):
                main.load_config(tmp)
        finally:
            tmp.unlink()

    def test_documents_present(self):
        cfg = main.load_config()
        self.assertEqual(main.missing_documents(cfg), [])

    def test_missing_documents(self):
        cfg = main.load_config()
        cfg["documentos"][cfg["request_type"]] = ["nao_existe.pdf"]
        self.assertEqual(main.missing_documents(cfg), ["nao_existe.pdf"])


class TestSelectOption(unittest.TestCase):
    def _run(self, options, wanted):
        el = MagicMock()
        with patch.object(main, "Select") as S:
            S.return_value.options = [FakeOption(t) for t in options]
            ok = main.select_option(el, wanted)
            chosen = S.return_value.select_by_visible_text.call_args
        return ok, chosen[0][0] if chosen else None

    def test_synonyms(self):
        self.assertEqual(self._run(["", "Si", "No"], "Yes"), (True, "Si"))
        self.assertEqual(self._run(["", "Sim", "Não"], "no"), (True, "Não"))

    def test_partial(self):
        self.assertEqual(self._run(["", "Celibe/Nubile", "Coniugato/a"], "coniugato"), (True, "Coniugato/a"))

    def test_not_found(self):
        self.assertEqual(self._run(["", "A", "B"], "Z"), (False, None))


class TestAvailability(unittest.TestCase):
    def _driver(self, ids=(), dialog=False, body=""):
        d = MagicMock()
        d.current_url = "https://prenotami.esteri.it/Services/Booking/1319"
        d.title = "Prenot@mi"

        def find_elements(by, value):
            if value in ids:
                return [MagicMock()]
            if "dialog" in value and dialog:
                m = MagicMock()
                m.is_displayed.return_value = True
                return [m]
            return []

        d.find_elements.side_effect = find_elements
        d.find_element.return_value.text = body
        return d

    def test_available(self):
        self.assertEqual(main.check_availability(self._driver(ids=("btnAvanti",)), 2), "disponivel")

    def test_unavailable_dialog(self):
        self.assertEqual(main.check_availability(self._driver(dialog=True), 2), "indisponivel")

    def test_unavailable_text(self):
        d = self._driver(body="Al momento non ci sono date disponibili per il servizio richiesto")
        self.assertEqual(main.check_availability(d, 2), "indisponivel")

    def test_logged_out(self):
        self.assertEqual(main.check_availability(self._driver(ids=("login-email",)), 2), "deslogado")

    def test_captcha(self):
        d = self._driver()
        d.current_url = "https://validate.perfdrive.com/abc"
        self.assertEqual(main.check_availability(d, 2), "captcha")

    def test_unknown(self):
        self.assertEqual(main.check_availability(self._driver(), 1), "desconhecido")


class TestCredentials(unittest.TestCase):
    def test_strips_quotes(self):
        with patch.object(main, "load_dotenv"), patch.dict(
            main.os.environ, {"PRENOTAMI_EMAIL": '"a@b.com"', "PRENOTAMI_SENHA": "'x'"}
        ):
            self.assertEqual(main.load_credentials(), ("a@b.com", "x"))


if __name__ == "__main__":
    unittest.main()
