# PrenotaBot (versão corrigida)

Assistente para agendar passaporte ou cidadania no [Prenot@mi](https://prenotami.esteri.it). Ele faz o login, verifica de tempos em tempos se há vagas no serviço escolhido e, quando o formulário abre, emite um alerta sonoro, preenche os campos e anexa os documentos. A escolha de data/horário e o código de confirmação ficam com você.

## Instalação no Windows (uma única vez)

1. Instale o **Python 3.10 ou mais novo** em python.org e marque "Add Python to PATH". Instale também o **Google Chrome**.
2. Extraia esta pasta em um local sem acentos, por exemplo `C:\prenotabot`.
3. Dê dois cliques em **`instalar.bat`**. Ele cria o ambiente virtual, instala as dependências e verifica a configuração.

Não é preciso baixar o ChromeDriver: o Selenium baixa automaticamente a versão compatível com o seu Chrome.

## Configuração

O arquivo **`.env`** guarda o seu login, uma informação por linha e **sem aspas**:

```
PRENOTAMI_EMAIL=seu_email@exemplo.com
PRENOTAMI_SENHA=sua_senha
```

O arquivo **`parameters.yaml`** guarda os dados do agendamento. Os pontos principais são:

| Opção | O que faz |
|---|---|
| `request_type` | `passport` ou `citizenship` |
| `service_ids` | Número do serviço no fim do link `.../Services/Booking/XXXX`. **Ele muda de um consulado para outro**, então confira no site. |
| `intervalo_min/max_segundos` | Intervalo aleatório entre as verificações (o mínimo aceito é 20 s) |
| `max_tentativas` | `0` = sem limite |
| `campos` | Respostas do formulário. Deixe `valor: ""` para preencher à mão. |
| `documentos` | PDFs da pasta `files/`, na ordem dos campos de upload |

Para ver as opções do **estado civil** (`ddls_4`), abra o formulário uma vez e copie o texto exato da opção (ex.: `Coniugato/a`, `Married`). Esse campo está vazio no momento, então você terá que preenchê-lo manualmente até configurá-lo.

## Uso

Dê dois cliques em **`executar.bat`** (ou rode `python main.py` com o ambiente ativado).

- Se aparecer um **captcha** (verificação anti-robô), o bot toca um alerta e espera. Resolva o captcha no Chrome e pressione ENTER no terminal.
- Se o login automático falhar, faça o login à mão no Chrome e pressione ENTER.
- O perfil do Chrome fica salvo em `chrome_profile/`, então a sessão é mantida entre uma execução e outra.
- Para parar, use **Ctrl+C**. Depois de concluir o agendamento, digite `sair`.
- O registro de tudo fica em `logs/prenotabot.log`.

Para só validar a configuração, sem abrir o navegador: `python main.py --verificar`.

## Problemas comuns

| Mensagem | Solução |
|---|---|
| `'source' não é reconhecido` | No Windows, use `.venv\Scripts\activate` (ou simplesmente o `instalar.bat`) |
| Erro ao compilar `PyYAML==6.0` | Já corrigido: o `requirements.txt` agora usa versões compatíveis com o Python 3.12+ |
| `No module named 'distutils'` / `'Version' object has no attribute 'vstring'` | Já corrigido: o `undetected_chromedriver` foi removido |
| `No such file or directory: C:\tmp\out.log` | Já corrigido: o log fica em `logs/` |
| "session not created" / versão do Chrome | Atualize o Chrome e rode de novo |

## Uso responsável

O consulado considera abusivo o uso de automação agressiva. Use o bot apenas para o seu próprio agendamento, com intervalos razoáveis, e não o use para revender vagas. Usar automação pode levar ao bloqueio da conta.
