"""
PrenotaBot - assistente de agendamento no Prenot@mi (prenotami.esteri.it)

O bot faz login, verifica periodicamente se o servico escolhido tem vagas e,
quando o formulario abre, preenche os campos configurados em parameters.yaml.
A confirmacao final (escolha de data/hora e codigo OTP) e feita por voce.

Uso:
    python main.py              # executa o bot
    python main.py --verificar  # so valida configuracao/arquivos, sem abrir o Chrome
"""

from __future__ import annotations

import argparse
import logging
import os
import random
import sys
import time
import unicodedata
from datetime import datetime
from pathlib import Path

import yaml
from dotenv import load_dotenv
from selenium import webdriver
from selenium.common.exceptions import (
    NoSuchElementException,
    TimeoutException,
    WebDriverException,
)
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait

BASE_DIR = Path(__file__).resolve().parent
FILES_DIR = BASE_DIR / "files"
LOGS_DIR = BASE_DIR / "logs"
CONFIG_PATH = BASE_DIR / "parameters.yaml"
ENV_PATH = BASE_DIR / ".env"

SITE_URL = "https://prenotami.esteri.it/"
BOOKING_URL = "https://prenotami.esteri.it/Services/Booking/{id}"

# Textos que o site mostra quando nao ha vagas (it / en / pt / es)
UNAVAILABLE_HINTS = (
    "al momento non ci sono date disponibili",
    "sorry, all appointments for this service are currently booked",
    "all appointments for this service are currently booked",
    "non ci sono date disponibili",
    "stante l'elevata richiesta",
    "no hay citas disponibles",
    "todas as vagas",
)

DEFAULT_CONFIG = {
    "request_type": "passport",
    "service_ids": {"citizenship": 2392, "passport": 1319},
    "intervalo_min_segundos": 45,
    "intervalo_max_segundos": 90,
    "max_tentativas": 0,  # 0 = sem limite
    "usar_perfil_persistente": True,
    "login_manual_se_falhar": True,
    "documentos": {"citizenship": ["residencia.pdf"], "passport": ["identidade.pdf", "residencia.pdf"]},
    "campos": {"citizenship": [], "passport": []},
}

log = logging.getLogger("prenotabot")


# --------------------------------------------------------------------------- #
# Infraestrutura
# --------------------------------------------------------------------------- #
def setup_logging() -> None:
    LOGS_DIR.mkdir(exist_ok=True)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%d/%m/%Y %H:%M:%S")
    log.setLevel(logging.INFO)
    log.handlers.clear()
    fh = logging.FileHandler(LOGS_DIR / "prenotabot.log", encoding="utf-8")
    fh.setFormatter(fmt)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    log.addHandler(fh)
    log.addHandler(sh)


def _normalize(text: str) -> str:
    text = unicodedata.normalize("NFKD", str(text)).encode("ascii", "ignore").decode()
    return " ".join(text.lower().split())


def _deep_merge(base: dict, extra: dict) -> dict:
    out = dict(base)
    for k, v in (extra or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config(path: Path = CONFIG_PATH) -> dict:
    if not path.is_file():
        raise SystemExit(f"Arquivo de configuracao nao encontrado: {path}")
    with open(path, "r", encoding="utf-8") as f:
        user_cfg = yaml.safe_load(f) or {}
    cfg = _deep_merge(DEFAULT_CONFIG, user_cfg)

    tipo = cfg["request_type"]
    if tipo not in cfg["service_ids"]:
        raise SystemExit(
            f"request_type '{tipo}' invalido. Use um de: {', '.join(cfg['service_ids'])}"
        )
    if cfg["intervalo_min_segundos"] > cfg["intervalo_max_segundos"]:
        raise SystemExit("intervalo_min_segundos nao pode ser maior que intervalo_max_segundos")
    if cfg["intervalo_min_segundos"] < 20:
        log.warning("Intervalo menor que 20s aumenta o risco de bloqueio da conta. Ajustando para 20s.")
        cfg["intervalo_min_segundos"] = 20
        cfg["intervalo_max_segundos"] = max(cfg["intervalo_max_segundos"], 20)
    return cfg


def load_credentials() -> tuple[str, str]:
    load_dotenv(ENV_PATH, override=True)
    user = (os.getenv("PRENOTAMI_EMAIL") or os.getenv("username") or "").strip().strip('"\'')
    pwd = (os.getenv("PRENOTAMI_SENHA") or os.getenv("password") or "").strip().strip('"\'')
    return user, pwd


def missing_documents(cfg: dict) -> list[str]:
    docs = cfg["documentos"].get(cfg["request_type"], [])
    return [d for d in docs if not (FILES_DIR / d).is_file()]


def alert(msg: str) -> None:
    """Alerta sonoro + log destacado (som so no Windows)."""
    log.info("=" * 60)
    log.info(msg)
    log.info("=" * 60)
    try:
        import winsound  # type: ignore

        for _ in range(5):
            winsound.Beep(1200, 400)
            time.sleep(0.15)
    except Exception:
        print("\a" * 3, end="", flush=True)


def save_page(driver, name: str) -> None:
    try:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        (LOGS_DIR / f"{name}_{stamp}.html").write_text(driver.page_source, encoding="utf-8")
    except Exception as e:  # pragma: no cover
        log.debug(f"Nao foi possivel salvar a pagina: {e}")


# --------------------------------------------------------------------------- #
# Navegador
# --------------------------------------------------------------------------- #
def build_driver(cfg: dict):
    """Chrome via Selenium Manager (baixa o driver correto automaticamente)."""
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--lang=pt-BR")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)
    if cfg.get("usar_perfil_persistente"):
        profile = BASE_DIR / "chrome_profile"
        profile.mkdir(exist_ok=True)
        options.add_argument(f"--user-data-dir={profile}")
    driver = webdriver.Chrome(options=options)
    driver.set_page_load_timeout(90)
    return driver


def is_captcha_page(driver) -> bool:
    url = driver.current_url.lower()
    title = (driver.title or "").lower()
    return "perfdrive" in url or "validate." in url or "captcha" in title


def wait_captcha(driver) -> None:
    """Pagina anti-bot (Radware): o usuario resolve manualmente."""
    if not is_captcha_page(driver):
        return
    alert("Verificacao anti-robo (captcha) na tela. Resolva no Chrome.")
    input(">>> Depois de resolver o captcha, pressione ENTER aqui... ")
    time.sleep(2)


# --------------------------------------------------------------------------- #
# Login
# --------------------------------------------------------------------------- #
def is_logged_in(driver) -> bool:
    url = driver.current_url.lower()
    if "/userarea" in url or "/services" in url:
        return not driver.find_elements(By.ID, "login-email")
    return bool(driver.find_elements(By.XPATH, "//a[contains(@href,'Logout')]"))


def login(driver, cfg: dict, email: str, password: str) -> bool:
    driver.get(SITE_URL)
    time.sleep(3)
    wait_captcha(driver)
    if is_logged_in(driver):
        log.info("Sessao ja estava ativa (perfil persistente).")
        return True

    try:
        email_box = WebDriverWait(driver, 60).until(
            EC.element_to_be_clickable((By.ID, "login-email"))
        )
        if email and password:
            email_box.clear()
            email_box.send_keys(email)
            pwd_box = driver.find_element(By.ID, "login-password")
            pwd_box.clear()
            pwd_box.send_keys(password)
            time.sleep(random.uniform(1.5, 3.0))
            buttons = driver.find_elements(
                By.XPATH, "//button[contains(@class,'g-recaptcha') or @type='submit']"
            )
            if buttons:
                buttons[0].click()
            WebDriverWait(driver, 40).until(lambda d: is_logged_in(d))
            log.info("Login realizado com sucesso.")
            return True
    except (TimeoutException, NoSuchElementException, WebDriverException) as e:
        log.warning(f"Login automatico nao concluido ({type(e).__name__}).")

    if cfg.get("login_manual_se_falhar"):
        input(
            "\n>>> Faca o login manualmente na janela do Chrome (resolva o captcha se aparecer)"
            "\n>>> e depois pressione ENTER aqui para continuar... "
        )
        if is_logged_in(driver):
            log.info("Login manual confirmado.")
            return True
    log.error("Nao foi possivel confirmar o login.")
    return False


# --------------------------------------------------------------------------- #
# Verificacao de disponibilidade
# --------------------------------------------------------------------------- #
def check_availability(driver, timeout: int = 30) -> str:
    """
    Retorna:
      'disponivel'   -> formulario de agendamento abriu
      'indisponivel' -> popup/aviso de falta de vagas
      'deslogado'    -> sessao expirou
      'captcha'      -> pagina anti-robo exige acao manual
      'desconhecido' -> nada reconhecivel (site lento/fora do ar)
    """

    def _state(d):
        if is_captcha_page(d):
            return "captcha"
        if d.find_elements(By.ID, "login-email"):
            return "deslogado"
        if d.find_elements(By.ID, "btnAvanti") or d.find_elements(By.ID, "PrivacyCheck"):
            return "disponivel"
        dialogs = d.find_elements(By.XPATH, "//div[@role='dialog' or contains(@class,'jconfirm')]")
        for dlg in dialogs:
            try:
                if dlg.is_displayed():
                    return "indisponivel"
            except WebDriverException:
                pass
        body = _normalize(d.find_element(By.TAG_NAME, "body").text)
        if any(h in body for h in UNAVAILABLE_HINTS):
            return "indisponivel"
        return False

    try:
        state = WebDriverWait(driver, timeout, poll_frequency=0.5).until(_state)
    except TimeoutException:
        return "desconhecido"

    if state == "indisponivel":
        # Fecha o popup "ok" para nao atrapalhar a proxima tentativa
        for btn in driver.find_elements(
            By.XPATH,
            "//div[@role='dialog']//button | //div[contains(@class,'jconfirm')]//button",
        ):
            try:
                if btn.is_displayed():
                    btn.click()
                    break
            except WebDriverException:
                pass
    return state


# --------------------------------------------------------------------------- #
# Preenchimento do formulario
# --------------------------------------------------------------------------- #
SYNONYMS = {
    "yes": ["yes", "si", "sim"],
    "no": ["no", "nao"],
}


def select_option(select_el, wanted: str) -> bool:
    """Seleciona uma opcao de forma tolerante (maiusculas, acentos, sim/si/yes)."""
    sel = Select(select_el)
    target = _normalize(wanted)
    candidates = {target}
    for group in SYNONYMS.values():
        if target in group:
            candidates.update(group)

    options = [(o, _normalize(o.text)) for o in sel.options]
    for opt, text in options:  # 1) correspondencia exata
        if text in candidates:
            sel.select_by_visible_text(opt.text)
            return True
    for opt, text in options:  # 2) correspondencia parcial
        if text and any(c in text or text in c for c in candidates):
            sel.select_by_visible_text(opt.text)
            return True
    log.warning(
        f"Opcao '{wanted}' nao encontrada no campo {select_el.get_attribute('id')}. "
        f"Opcoes: {[o.text for o, _ in options]}"
    )
    return False


def fill_form(driver, cfg: dict) -> None:
    tipo = cfg["request_type"]
    for campo in cfg["campos"].get(tipo, []) or []:
        fid, kind, valor = campo.get("id"), campo.get("tipo", "texto"), campo.get("valor", "")
        if valor in (None, ""):
            log.info(f"Campo {fid} sem valor configurado - preencha manualmente.")
            continue
        try:
            el = driver.find_element(By.ID, fid)
            if kind == "select":
                select_option(el, str(valor))
            else:
                el.clear()
                el.send_keys(str(valor))
            time.sleep(random.uniform(0.3, 0.8))
        except NoSuchElementException:
            log.warning(f"Campo {fid} nao existe neste formulario (ignorado).")

    # Upload dos documentos: File_0, File_1, ... na ordem configurada
    for i, doc in enumerate(cfg["documentos"].get(tipo, [])):
        inputs = driver.find_elements(By.ID, f"File_{i}")
        if inputs:
            inputs[0].send_keys(str(FILES_DIR / doc))
            log.info(f"Documento anexado: {doc}")
            time.sleep(0.8)
        else:
            log.warning(f"Campo de upload File_{i} nao encontrado para {doc}.")

    privacy = driver.find_elements(By.ID, "PrivacyCheck")
    if privacy and not privacy[0].is_selected():
        privacy[0].click()

    if cfg.get("clicar_avancar", True):
        btn = driver.find_elements(By.ID, "btnAvanti")
        if btn:
            btn[0].click()
            log.info("Formulario enviado (Avanti). Escolha data/horario na janela do Chrome.")


# --------------------------------------------------------------------------- #
# Fluxo principal
# --------------------------------------------------------------------------- #
def wait_for_exit(driver) -> None:
    print()
    while True:
        try:
            cmd = input(">>> Conclua o agendamento no navegador. Digite 'sair' para fechar: ")
        except (EOFError, KeyboardInterrupt):
            break
        if cmd.strip().lower() in ("sair", "quit", "exit", "q"):
            break
    try:
        driver.quit()
    except Exception:
        pass


def run(cfg: dict) -> int:
    email, password = load_credentials()
    if not (email and password):
        log.warning("Credenciais nao encontradas no .env - sera necessario login manual.")

    tipo = cfg["request_type"]
    url = BOOKING_URL.format(id=cfg["service_ids"][tipo])
    log.info(f"Servico: {tipo} -> {url}")

    driver = build_driver(cfg)
    try:
        if not login(driver, cfg, email, password):
            return 1

        tentativa = 0
        max_t = int(cfg.get("max_tentativas") or 0)
        falhas_seguidas = 0
        while max_t == 0 or tentativa < max_t:
            tentativa += 1
            try:
                driver.get(url)
                state = check_availability(driver)
            except WebDriverException as e:
                state = "desconhecido"
                log.warning(f"Erro de navegacao: {e.msg if hasattr(e, 'msg') else e}")

            log.info(f"Tentativa {tentativa}{'/' + str(max_t) if max_t else ''}: {state}")

            if state == "disponivel":
                alert("VAGA ENCONTRADA! Preenchendo o formulario...")
                save_page(driver, f"formulario_{tipo}")
                fill_form(driver, cfg)
                wait_for_exit(driver)
                return 0

            if state == "captcha":
                wait_captcha(driver)
                continue

            if state == "deslogado":
                log.info("Sessao expirada. Refazendo login...")
                if not login(driver, cfg, email, password):
                    return 1
                continue

            falhas_seguidas = falhas_seguidas + 1 if state == "desconhecido" else 0
            espera = random.uniform(cfg["intervalo_min_segundos"], cfg["intervalo_max_segundos"])
            if falhas_seguidas >= 3:  # site instavel: espera mais
                espera *= 2
                save_page(driver, "pagina_desconhecida")
            log.info(f"Aguardando {espera:.0f}s ate a proxima verificacao...")
            time.sleep(espera)

        log.info("Numero maximo de tentativas atingido sem vagas.")
        wait_for_exit(driver)
        return 0
    except KeyboardInterrupt:
        log.info("Interrompido pelo usuario (Ctrl+C).")
        try:
            driver.quit()
        except Exception:
            pass
        return 130


def preflight(cfg: dict) -> bool:
    ok = True
    faltando = missing_documents(cfg)
    if faltando:
        ok = False
        log.error(f"Documentos faltando em {FILES_DIR}: {', '.join(faltando)}")
    else:
        log.info("Documentos encontrados.")
    email, password = load_credentials()
    log.info(f"Credenciais no .env: {'OK (' + email + ')' if email and password else 'NAO encontradas'}")
    log.info(f"Tipo de servico: {cfg['request_type']} (ID {cfg['service_ids'][cfg['request_type']]})")
    for campo in cfg["campos"].get(cfg["request_type"], []) or []:
        if campo.get("valor") in (None, ""):
            log.warning(f"Campo '{campo.get('descricao', campo.get('id'))}' esta vazio no parameters.yaml.")
    return ok


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="PrenotaBot - Prenot@mi")
    parser.add_argument("--verificar", action="store_true", help="so valida a configuracao")
    args = parser.parse_args(argv)

    setup_logging()
    cfg = load_config()
    if not preflight(cfg):
        log.error("Corrija os itens acima e rode novamente (veja o LEIAME.md).")
        return 1
    if args.verificar:
        log.info("Configuracao OK.")
        return 0
    return run(cfg)


if __name__ == "__main__":
    sys.exit(main())
