# PrenotaBot Livre no celular (Android)

O Chrome do Android **não aceita extensões**. Por isso a versão para celular do PrenotaBot é um *userscript*, um script que roda dentro do site do Prenot@mi por meio de um gerenciador gratuito. Ele faz no celular o mesmo trabalho do programa de PC: entra na sua conta, verifica as vagas, toca o alarme, preenche o formulário, anexa o PDF, escolhe o horário e salva o comprovante.

![Painel no celular](../docs/imagens/celular_painel.png)

## Instalação (uns 5 minutos, uma vez só)

**Caminho recomendado: Firefox + Tampermonkey**

1. Na Play Store, instale o **Firefox**.
2. No Firefox, abra o menu (⋮), vá em **Extensões** e instale o **Tampermonkey** (ou o **Violentmonkey**).
3. Abra o Tampermonkey (menu ⋮ → Extensões → Tampermonkey → **Painel**). Depois, use **um** destes caminhos:
   - **Pelo link (mais fácil):** vá em **Utilitários → Instalar a partir do URL**, cole o link do script que veio junto com este pacote e toque em **Instalar**.
   - **Copiando e colando:** mande o arquivo `prenotabot-livre.user.js` para o celular (WhatsApp para você mesmo, Google Drive etc.) e abra-o num editor de texto. Depois, toque em **+ (novo script)** no Tampermonkey, apague o texto de exemplo, cole todo o conteúdo do arquivo e salve.
   - **Pelo arquivo:** em **Utilitários → Importar do arquivo**, selecione o `prenotabot-livre.user.js`. Esse caminho funciona em algumas versões.
4. Confira se o script **PrenotaBot Livre** aparece na lista e está ativado.

**Outras opções:** o **Lemur Browser** tem suporte a userscripts e instala o Tampermonkey pela Chrome Web Store. No **Quetta**, basta instalar o Tampermonkey pela loja e seguir o passo 4. O Kiwi Browser foi descontinuado em janeiro de 2025 e não é recomendado.

## Como usar

1. No navegador onde instalou o script, abra **https://prenotami.esteri.it**.
2. Um botão redondo **PB** aparece no canto de baixo. Toque nele.
3. Preencha os 6 blocos: conta, serviço (*São Paulo – PRIMEIRO PASSAPORTE* já vem marcado), dados do formulário, documento (comprovante de residência em PDF), opções e avisos.
4. Toque em **Salvar** e depois em **INICIAR MONITORAMENTO**.
5. Deixe a aba aberta, com a tela ligada e o celular no carregador. Enquanto monitora, o botão fica vermelho e aparece **ON**.

## Quando a vaga abrir

O celular toca um alarme e vibra. Você também recebe a notificação do app **ntfy** e, se tiver configurado, uma mensagem no WhatsApp ou no Telegram. Em seguida, o script:

- preenche endereço, estado civil, altura e cor dos olhos (nos campos exatos do serviço 5402);
- anexa o PDF e marca a caixa de privacidade;
- pede o **código OTP**, que chega no seu e-mail.

**Você digita o código de 6 números** e o script clica em *Avançar* sozinho. No calendário, ele procura e reserva o primeiro horário livre que esteja dentro das suas preferências. Na tela de confirmação, salva uma cópia do comprovante em *Downloads*.

Se aparecer um campo que o script não conhece, ele fica destacado em vermelho. Preencha esse campo e o script **aprende a resposta** para a próxima vez.

## Dicas importantes

- **Alarme:** o navegador só libera o som depois que você toca na página. Por isso, o bipe de teste toca quando você aperta INICIAR. O jeito mais garantido de ser avisado é o app **ntfy**: no tópico, ative a prioridade máxima e o som de alarme.
- **Segundo plano:** o Android pausa as abas que ficam em segundo plano. Para monitorar por muito tempo, deixe o navegador aberto na frente, com a tela ligada (o script tenta mantê-la acesa). Outra opção é usar o programa de PC, que roda minimizado.
- **Captcha:** quando o site mostra o captcha da Radware, o script para e avisa. Resolva o captcha que o monitoramento continua.
- **Intervalo:** não use menos de 45 segundos. Verificar rápido demais faz o site bloquear a conta por alguns minutos (página `/Error`). Nesse caso, o script espera sozinho.
- **Privacidade:** a senha e os documentos ficam guardados só no armazenamento do Tampermonkey, neste aparelho. O script não tem rastreador e não manda nada para servidores, a não ser os avisos que você configurar.
