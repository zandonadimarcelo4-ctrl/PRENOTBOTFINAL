// ==UserScript==
// @name         PrenotaBot Livre (celular e PC)
// @namespace    https://github.com/prenotabot-livre
// @version      2.0.0
// @description  Monitora vagas no Prenot@mi, preenche o formulario, anexa documentos, escolhe o horario e avisa no celular. Gratis, sem rastreamento: tudo fica no seu aparelho.
// @author       PrenotaBot Livre
// @match        https://prenotami.esteri.it/*
// @match        https://iam.esteri.it/*
// @match        https://validate.perfdrive.com/*
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_xmlhttpRequest
// @grant        GM_notification
// @connect      ntfy.sh
// @connect      api.callmebot.com
// @connect      api.telegram.org
// @run-at       document-idle
// @noframes
// ==/UserScript==

/* PrenotaBot Livre - versao userscript
 * Funciona no Android com: Firefox + Tampermonkey (ou Violentmonkey), Lemur Browser (userscripts) e Quetta + Tampermonkey.
 * No PC: Chrome/Edge/Firefox + Tampermonkey.
 * Nada e enviado para servidores de terceiros alem dos avisos que VOCE configurar (ntfy / WhatsApp CallMeBot / Telegram).
 */
(function () {
  'use strict';

  const SITE = 'https://prenotami.esteri.it';
  const VERSION = '2.0.0';

  // ------------------------------------------------------------------ armazenamento
  const hasGM = typeof GM_getValue === 'function';
  const store = {
    get(k, d) {
      try {
        const v = hasGM ? GM_getValue(k) : localStorage.getItem('pbl_' + k);
        if (v === undefined || v === null) return d;
        return typeof v === 'string' && hasGM === false ? JSON.parse(v) : v;
      } catch (e) { return d; }
    },
    set(k, v) {
      if (hasGM) GM_setValue(k, v); else localStorage.setItem('pbl_' + k, JSON.stringify(v));
    },
  };

  const DEFAULTS = {
    email: '', senha: '', servicos: '5402',
    intervalo_min: 45, intervalo_max: 90, espera_bloqueio_min: 10,
    auto_login: true, somente_alertar: false, preencher: true, clicar_avancar: true, auto_agendar: true,
    meses: 4, periodo: 'qualquer', data_min: '', data_max: '',
    dados: {endereco: '', altura_cm: '', estado_civil: '', cor_olhos: '', filhos_menores: 'Nao',
            quantidade_filhos: '0', passaporte_vencido: 'Nao', data_vencimento_passaporte: '', observacoes: ''},
    acompanhantes: [],  // [{nome, sobrenome, nascimento:'dd/mm/aaaa', parentesco}]
    ntfy: '', zap_tel: '', zap_key: '', tg_token: '', tg_chat: '',
    respostas_aprendidas: {},
  };
  const cfg = () => Object.assign({}, DEFAULTS, store.get('cfg', {}), {dados: Object.assign({}, DEFAULTS.dados, (store.get('cfg', {}) || {}).dados || {})});
  const saveCfg = c => store.set('cfg', c);
  const running = () => !!store.get('running', false);
  const setRunning = v => store.set('running', !!v);
  const docs = () => store.get('docs', []);  // [{nome, tipo, dataUrl}]

  // ------------------------------------------------------------------ utilidades
  const norm = s => String(s || '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const rand = (a, b) => a + Math.random() * (b - a);
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const visible = el => !!(el && (el.offsetParent || el.getClientRects().length));
  const path = () => location.pathname.toLowerCase();
  const host = () => location.hostname.toLowerCase();
  const serviceList = () => String(cfg().servicos || '').split(/[ ,;]+/).map(s => s.trim()).filter(s => /^\d+$/.test(s));
  const logLines = store.get('log', []);
  function log(msg) {
    const line = new Date().toLocaleTimeString('pt-BR') + '  ' + msg;
    console.log('[PrenotaBot] ' + msg);
    logLines.push(line);
    while (logLines.length > 60) logLines.shift();
    store.set('log', logLines);
    renderLog();
  }

  // ------------------------------------------------------------------ alarme e avisos
  let audioCtx = null;
  function beep(times = 6) {
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === 'suspended') audioCtx.resume();
      for (let i = 0; i < times; i++) {
        const o = audioCtx.createOscillator(), g = audioCtx.createGain();
        o.type = 'square'; o.frequency.value = i % 2 ? 880 : 1320;
        g.gain.value = 0.25;
        o.connect(g); g.connect(audioCtx.destination);
        const t = audioCtx.currentTime + i * 0.45;
        o.start(t); o.stop(t + 0.3);
      }
    } catch (e) { /* sem audio */ }
    try { navigator.vibrate && navigator.vibrate([400, 150, 400, 150, 800]); } catch (e) {}
  }
  function http(url, method = 'GET', data = null, headers = {}) {
    return new Promise(resolve => {
      if (typeof GM_xmlhttpRequest === 'function') {
        GM_xmlhttpRequest({method, url, data, headers, timeout: 15000,
          onload: r => resolve(r.status < 400), onerror: () => resolve(false), ontimeout: () => resolve(false)});
      } else {
        fetch(url, {method, body: data, headers, mode: 'cors'}).then(r => resolve(r.ok)).catch(() => resolve(false));
      }
    });
  }
  async function notify(text, important = true) {
    const c = cfg();
    const res = {};
    if (c.ntfy) {
      const url = c.ntfy.startsWith('http') ? c.ntfy : 'https://ntfy.sh/' + encodeURIComponent(c.ntfy);
      res.ntfy = await http(url, 'POST', text, {Title: 'PrenotaBot', Priority: important ? 'urgent' : 'high', Tags: 'rotating_light'});
    }
    if (c.zap_tel && c.zap_key && important) {
      const q = new URLSearchParams({phone: c.zap_tel.replace(/[^\d+]/g, ''), text, apikey: c.zap_key});
      res.whatsapp = await http('https://api.callmebot.com/whatsapp.php?' + q.toString());
    }
    if (c.tg_token && c.tg_chat) {
      const q = new URLSearchParams({chat_id: c.tg_chat, text});
      res.telegram = await http(`https://api.telegram.org/bot${c.tg_token}/sendMessage?` + q.toString());
    }
    try {
      if (typeof GM_notification === 'function') GM_notification({title: 'PrenotaBot', text, timeout: 0});
    } catch (e) {}
    return res;
  }
  function alarm(text, important = true) {
    log(text);
    beep();
    banner(text, 'alert');
    notify('PrenotaBot: ' + text, important);
  }

  // ------------------------------------------------------------------ interface (botao + painel)
  const STYLE = `
  #pbl-fab{position:fixed;right:14px;bottom:14px;z-index:2147483646;width:58px;height:58px;border-radius:50%;
    background:#1f2a36;color:#fff;font:700 17px system-ui,sans-serif;border:3px solid #009246;box-shadow:0 4px 14px #0006;cursor:pointer}
  #pbl-fab.on{border-color:#ce2b37;animation:pblp 1.6s infinite}
  @keyframes pblp{50%{box-shadow:0 0 0 10px #ce2b3733}}
  #pbl-banner{position:fixed;left:0;right:0;top:0;z-index:2147483645;padding:10px 14px;font:600 15px system-ui,sans-serif;
    color:#fff;background:#1f2a36;border-bottom:4px solid #009246;display:none;text-align:center}
  #pbl-banner.alert{background:#ce2b37;border-color:#fff}
  #pbl-panel{position:fixed;inset:0;z-index:2147483647;background:#f4f5f7;overflow:auto;display:none;font:15px system-ui,sans-serif;color:#1d232a}
  #pbl-panel .hd{background:#1f2a36;color:#fff;padding:14px 16px;position:sticky;top:0;z-index:2}
  #pbl-panel .hd b{font-size:19px}#pbl-panel .hd small{display:block;color:#cfd8dc}
  #pbl-panel .flag{height:5px;background:linear-gradient(90deg,#009246 33%,#fff 33% 66%,#ce2b37 66%)}
  #pbl-panel .x{position:absolute;right:12px;top:10px;background:none;border:0;color:#fff;font-size:28px}
  #pbl-panel section{background:#fff;margin:12px;border-radius:12px;padding:12px 14px;box-shadow:0 1px 4px #0001}
  #pbl-panel h3{margin:0 0 8px;font-size:16px;color:#1f2a36}
  #pbl-panel label{display:block;margin:8px 0 3px;font-size:13px;color:#455a64}
  #pbl-panel input[type=text],#pbl-panel input[type=password],#pbl-panel input[type=number],#pbl-panel input[type=email],#pbl-panel select,#pbl-panel textarea{
    width:100%;box-sizing:border-box;padding:10px;border:1px solid #cfd8dc;border-radius:8px;font-size:15px;background:#fff}
  #pbl-panel .ck{display:flex;align-items:center;gap:8px;margin:8px 0;font-size:14px;color:#1d232a}
  #pbl-panel .ck input{width:20px;height:20px}
  #pbl-panel .row{display:flex;gap:8px}#pbl-panel .row>*{flex:1}
  #pbl-panel .btn{display:inline-block;padding:11px 14px;border-radius:9px;border:1px solid #cfd8dc;background:#eceff1;font-weight:600;font-size:14px;margin:6px 6px 0 0}
  #pbl-panel .go{background:#009246;color:#fff;border-color:#009246;font-size:17px;width:100%;padding:15px}
  #pbl-panel .stop{background:#ce2b37;color:#fff;border-color:#ce2b37;font-size:17px;width:100%;padding:15px}
  #pbl-panel .hint{font-size:12px;color:#78909c;margin-top:4px}
  #pbl-panel .ok{color:#2e7d32}
  #pbl-panel .opt{display:block;border:1px solid #cfd8dc;border-radius:10px;padding:10px;margin:6px 0}
  #pbl-panel .opt input{margin-right:6px}
  #pbl-log{font:12px ui-monospace,monospace;background:#111;color:#b9f6ca;padding:8px;border-radius:8px;max-height:200px;overflow:auto;white-space:pre-wrap}
  #pbl-docs li{margin:4px 0}`;

  function el(tag, attrs = {}, html = '') {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
    if (html) e.innerHTML = html;
    return e;
  }

  function banner(text, kind = '') {
    let b = $('#pbl-banner');
    if (!b) return;
    b.textContent = text;
    b.className = kind;
    b.style.display = text ? 'block' : 'none';
  }

  function renderLog() {
    const l = $('#pbl-log');
    if (l) { l.textContent = logLines.slice().reverse().join('\n'); }
  }

  const OPT = (vals, cur) => vals.map(v => `<option ${norm(v) === norm(cur) ? 'selected' : ''}>${v}</option>`).join('');

  function buildUI() {
    if ($('#pbl-fab')) return;
    document.head.appendChild(el('style', {}, STYLE));
    document.body.appendChild(el('div', {id: 'pbl-banner'}));
    const fab = el('button', {id: 'pbl-fab', title: 'PrenotaBot Livre'}, 'PB');
    fab.onclick = () => openPanel();
    document.body.appendChild(fab);
    document.body.appendChild(el('div', {id: 'pbl-panel'}));
    refreshFab();
    if (!cfg().email && !store.get('visto', false)) { store.set('visto', true); openPanel(); }
  }

  function refreshFab() {
    const f = $('#pbl-fab');
    if (f) { f.classList.toggle('on', running()); f.textContent = running() ? 'ON' : 'PB'; }
  }

  function openPanel() {
    const c = cfg(), d = c.dados, p = $('#pbl-panel');
    const sv = serviceList()[0] || '5402';
    p.innerHTML = `
    <div class="hd"><b>PrenotaBot Livre</b><small>Primeiro passaporte no Prenot@mi - grátis, v${VERSION}</small>
      <button class="x" id="pbl-close">×</button></div><div class="flag"></div>
    <section>
      ${running()
        ? '<button class="btn stop" id="pbl-stop">PARAR MONITORAMENTO</button>'
        : '<button class="btn go" id="pbl-start">INICIAR MONITORAMENTO</button>'}
      <div class="hint">Tentativas: ${store.get('tentativas', 0)} · Deixe esta aba aberta, a tela ligada e o celular no carregador.</div>
    </section>
    <section><h3>1. Sua conta do Prenot@mi</h3>
      <label>E-mail</label><input type="email" id="pbl-email" value="${esc(c.email)}">
      <label>Senha</label><input type="password" id="pbl-senha" value="${esc(c.senha)}">
      <div class="ck"><input type="checkbox" id="pbl-autologin" ${c.auto_login ? 'checked' : ''}> Entrar sozinho na conta</div>
      <div class="hint">Fica salvo só neste navegador.</div>
    </section>
    <section><h3>2. O que agendar</h3>
      <label class="opt"><input type="radio" name="pbl-sv" value="5402" ${sv === '5402' ? 'checked' : ''}><b>São Paulo – PRIMEIRO PASSAPORTE</b><div class="hint">Anexo: comprovante de residência em seu nome (PDF).</div></label>
      <label class="opt"><input type="radio" name="pbl-sv" value="5256" ${sv === '5256' ? 'checked' : ''}><b>São Paulo – Renovação</b><div class="hint">Anexo: cópia do passaporte vencido / a vencer em até 12 meses.</div></label>
      <label class="opt"><input type="radio" name="pbl-sv" value="outro" ${!['5402', '5256'].includes(sv) ? 'checked' : ''}><b>Outro serviço / consulado</b>
        <input type="text" id="pbl-svid" placeholder="número(s) do serviço, ex.: 4705" value="${['5402', '5256'].includes(sv) ? '' : esc(c.servicos)}"></label>
      <div class="hint">O número é o fim do link do botão "Prenota": .../Services/Booking/<b>5402</b>. Mato Grosso: passaporte é no Vice-Consulado de Cuiabá (serviço próprio na sua conta).</div>
    </section>
    <section><h3>3. Seus dados do formulário</h3>
      <label>Endereço completo *</label><input type="text" id="pbl-end" value="${esc(d.endereco)}" placeholder="Rua, número, bairro, cidade, estado, CEP">
      <div class="row"><div><label>Altura (cm)</label><input type="number" id="pbl-alt" value="${esc(d.altura_cm)}"></div>
        <div><label>Cor dos olhos</label><select id="pbl-olhos"><option></option>${OPT(['Castanho', 'Preto', 'Azul', 'Verde', 'Cinza'], d.cor_olhos)}</select></div></div>
      <label>Estado civil</label><select id="pbl-civil"><option></option>${OPT(['Solteiro/a', 'Casado/a', 'Divorciado/a', 'Viúvo/a', 'Separado/a', 'Em união civil'], d.estado_civil)}</select>
      <div class="row"><div><label>Filhos menores?</label><select id="pbl-fm">${OPT(['Não', 'Sim'], d.filhos_menores)}</select></div>
        <div><label>Qtde. filhos</label><input type="number" id="pbl-qf" value="${esc(d.quantidade_filhos)}"></div></div>
      <div class="row"><div><label>Passaporte vencido?</label><select id="pbl-pv">${OPT(['Não', 'Sim'], d.passaporte_vencido)}</select></div>
        <div><label>Vencimento</label><input type="text" id="pbl-venc" placeholder="dd/mm/aaaa" value="${esc(d.data_vencimento_passaporte)}"></div></div>
      <label>Observações (opcional)</label><input type="text" id="pbl-obs" value="${esc(d.observacoes)}">
    </section>
    <section><h3>4. Documentos (na ordem dos anexos do site)</h3>
      <ul id="pbl-docs"></ul>
      <input type="file" id="pbl-file" accept="application/pdf,image/*">
      <div class="hint">PDF de até 2 MB, legível e em seu nome. Para o primeiro passaporte em SP: comprovante de residência.</div>
    </section>
    <section><h3>5. Quando a vaga abrir</h3>
      <div class="ck"><input type="checkbox" id="pbl-pre" ${c.preencher ? 'checked' : ''}> Preencher o formulário e anexar</div>
      <div class="ck"><input type="checkbox" id="pbl-av" ${c.clicar_avancar ? 'checked' : ''}> Avançar sozinho (depois do código do e-mail)</div>
      <div class="ck"><input type="checkbox" id="pbl-ag" ${c.auto_agendar ? 'checked' : ''}> Escolher data e horário automaticamente</div>
      <div class="ck"><input type="checkbox" id="pbl-so" ${c.somente_alertar ? 'checked' : ''}> Só avisar (não mexer em nada)</div>
      <div class="row"><div><label>Período</label><select id="pbl-per">${OPT(['qualquer', 'manha', 'tarde'], c.periodo)}</select></div>
        <div><label>Meses a procurar</label><input type="number" id="pbl-meses" value="${esc(c.meses)}"></div></div>
      <div class="row"><div><label>Data mínima</label><input type="text" id="pbl-dmin" placeholder="dd/mm/aaaa" value="${esc(c.data_min)}"></div>
        <div><label>Data máxima</label><input type="text" id="pbl-dmax" placeholder="dd/mm/aaaa" value="${esc(c.data_max)}"></div></div>
      <div class="row"><div><label>Intervalo mín. (s)</label><input type="number" id="pbl-imin" value="${esc(c.intervalo_min)}"></div>
        <div><label>Intervalo máx. (s)</label><input type="number" id="pbl-imax" value="${esc(c.intervalo_max)}"></div></div>
    </section>
    <section><h3>6. Avisos no celular (grátis)</h3>
      <label>Tópico do app ntfy</label><div class="row"><input type="text" id="pbl-ntfy" value="${esc(c.ntfy)}"><button class="btn" id="pbl-gen" style="flex:0 0 auto">Gerar</button></div>
      <div class="hint">Instale o app "ntfy" (Play Store), toque em + e digite o mesmo tópico. O aviso chega mesmo com o navegador em segundo plano.</div>
      <label>WhatsApp (CallMeBot) – seu número</label><input type="text" id="pbl-zt" placeholder="+5566999999999" value="${esc(c.zap_tel)}">
      <label>API key do CallMeBot</label><input type="text" id="pbl-zk" value="${esc(c.zap_key)}">
      <div class="hint">Mande "I allow callmebot to send me messages" para +34 644 71 81 99 no WhatsApp e cole a chave recebida.</div>
      <div class="row"><div><label>Telegram token</label><input type="text" id="pbl-tt" value="${esc(c.tg_token)}"></div>
        <div><label>Chat ID</label><input type="text" id="pbl-tc" value="${esc(c.tg_chat)}"></div></div>
      <button class="btn" id="pbl-test">Testar avisos e alarme</button>
    </section>
    <section><button class="btn go" id="pbl-save">Salvar</button>
      <h3 style="margin-top:14px">Registro</h3><div id="pbl-log"></div>
      <button class="btn" id="pbl-clr">Limpar registro</button> <button class="btn" id="pbl-reset">Zerar contador</button>
      <div class="hint">Captcha e o código enviado por e-mail sempre ficam com você: o bot para, toca o alarme e avisa.</div>
    </section>`;
    p.style.display = 'block';
    renderDocs(); renderLog();
    $('#pbl-close').onclick = () => { p.style.display = 'none'; };
    $('#pbl-save').onclick = () => { collect(); p.style.display = 'none'; banner('Configuração salva.', ''); setTimeout(() => banner(''), 2500); };
    $('#pbl-gen').onclick = () => { $('#pbl-ntfy').value = 'prenotabot-' + Math.random().toString(36).slice(2, 10); };
    $('#pbl-test').onclick = async () => { collect(); beep(4); const r = await notify('PrenotaBot: teste de aviso. Se chegou, está tudo certo!', true); alert('Resultado: ' + (JSON.stringify(r) === '{}' ? 'nenhum canal configurado (só alarme)' : JSON.stringify(r))); };
    $('#pbl-clr').onclick = () => { logLines.length = 0; store.set('log', []); renderLog(); };
    $('#pbl-reset').onclick = () => { store.set('tentativas', 0); openPanel(); };
    $('#pbl-file').onchange = ev => addDoc(ev.target.files[0]);
    const st = $('#pbl-start'), sp = $('#pbl-stop');
    if (st) st.onclick = () => {
      collect();
      const c2 = cfg();
      if (!serviceList().length) return alert('Escolha o serviço (passo 2).');
      if (c2.auto_login && !(c2.email && c2.senha)) return alert('Preencha e-mail e senha (passo 1) ou desmarque "Entrar sozinho".');
      if (c2.preencher && !c2.dados.endereco) return alert('O endereço é obrigatório no formulário do consulado (passo 3).');
      beep(1);  // libera o audio (o navegador exige um toque)
      setRunning(true); store.set('idx', 0); p.style.display = 'none'; refreshFab();
      log('Monitoramento iniciado: serviço ' + serviceList().join(', '));
      tick();
    };
    if (sp) sp.onclick = () => { setRunning(false); refreshFab(); log('Monitoramento parado.'); banner(''); openPanel(); };
  }

  function esc(v) { return String(v ?? '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;'); }

  function collect() {
    const c = cfg(), v = id => ($('#' + id) || {}).value || '', ck = id => !!($('#' + id) || {}).checked;
    c.email = v('pbl-email').trim(); c.senha = v('pbl-senha'); c.auto_login = ck('pbl-autologin');
    const r = ($$('input[name=pbl-sv]').find(x => x.checked) || {}).value || '5402';
    c.servicos = r === 'outro' ? v('pbl-svid') : r;
    Object.assign(c.dados, {endereco: v('pbl-end').trim(), altura_cm: v('pbl-alt'), cor_olhos: v('pbl-olhos'),
      estado_civil: v('pbl-civil'), filhos_menores: v('pbl-fm'), quantidade_filhos: v('pbl-qf'),
      passaporte_vencido: v('pbl-pv'), data_vencimento_passaporte: v('pbl-venc'), observacoes: v('pbl-obs')});
    c.preencher = ck('pbl-pre'); c.clicar_avancar = ck('pbl-av'); c.auto_agendar = ck('pbl-ag'); c.somente_alertar = ck('pbl-so');
    c.periodo = v('pbl-per') || 'qualquer'; c.meses = Math.max(1, +v('pbl-meses') || 4);
    c.data_min = v('pbl-dmin'); c.data_max = v('pbl-dmax');
    c.intervalo_min = Math.max(20, +v('pbl-imin') || 45); c.intervalo_max = Math.max(c.intervalo_min, +v('pbl-imax') || 90);
    c.ntfy = v('pbl-ntfy').trim(); c.zap_tel = v('pbl-zt').trim(); c.zap_key = v('pbl-zk').trim();
    c.tg_token = v('pbl-tt').trim(); c.tg_chat = v('pbl-tc').trim();
    saveCfg(c);
  }

  function renderDocs() {
    const ul = $('#pbl-docs');
    if (!ul) return;
    const ds = docs();
    ul.innerHTML = ds.length ? '' : '<li class="hint">Nenhum documento ainda.</li>';
    ds.forEach((d, i) => {
      const li = el('li', {}, `<span class="ok">✔</span> ${i + 1}. ${esc(d.nome)} <small>(${Math.round(d.dataUrl.length * 0.75 / 1024)} KB)</small> `);
      const b = el('button', {class: 'btn'}, 'remover');
      b.onclick = () => { const x = docs(); x.splice(i, 1); store.set('docs', x); renderDocs(); };
      li.appendChild(b); ul.appendChild(li);
    });
  }

  function addDoc(file) {
    if (!file) return;
    if (file.size > 3 * 1024 * 1024 && !confirm('Arquivo com mais de 3 MB - o site pode recusar. Adicionar mesmo assim?')) return;
    const fr = new FileReader();
    fr.onload = () => {
      const x = docs(); x.push({nome: file.name, tipo: file.type || 'application/pdf', dataUrl: fr.result});
      store.set('docs', x); renderDocs(); $('#pbl-file').value = '';
    };
    fr.readAsDataURL(file);
  }

  // ------------------------------------------------------------------ preenchimento
  const FIELD_RULES = [
    ['quantidade_filhos', ['numero figli', 'numero di figli', 'quanti figli', 'quantidade de filhos', 'numero de filhos', 'number of children', 'n. figli']],
    ['filhos_menores', ['figli minor', 'filhos menores', 'minor children', 'underage', 'hijos menores', 'children under']],
    ['data_vencimento_passaporte', ['data di scadenza', 'data scadenza', 'data de vencimento', 'expiry date', 'expiration date']],
    ['passaporte_vencido', ['passaporto scaduto', 'passaporte vencido', 'expired passport', 'passaporto in scadenza']],
    ['estado_civil', ['stato civile', 'estado civil', 'marital status', 'civil status']],
    ['cor_olhos', ['colore occhi', 'colore degli occhi', 'cor dos olhos', 'eye color', 'eyes colour']],
    ['altura_cm', ['altezza', 'altura', 'statura', 'height']],
    ['endereco', ['indirizzo', 'endereco', 'address', 'residenza', 'domicilio']],
  ];
  const PRESETS = {
    5402: {'DatiAddizionaliPrenotante[0]._testo': 'endereco', ddls_1: 'estado_civil', 'DatiAddizionaliPrenotante[2]._testo': 'altura_cm', ddls_3: 'cor_olhos'},
    5256: {'DatiAddizionaliPrenotante[0]._testo': 'endereco', ddls_1: 'estado_civil', 'DatiAddizionaliPrenotante[2]._testo': 'altura_cm', ddls_3: 'cor_olhos',
           'DatiAddizionaliPrenotante[4]._testo': 'quantidade_filhos', 'DatiAddizionaliPrenotante[5]._data': 'data_vencimento_passaporte'},
  };
  const CODES = {
    estado_civil: {casado: '13', divorciado: '14', viuvo: '15', solteiro: '16', separado: '17', 'em uniao civil': '18'},
    cor_olhos: {azul: '22', marrom: '23', castanho: '23', cinza: '24', preto: '25', verde: '26'},
    filhos_menores: {sim: '11', nao: '12'},
    passaporte_vencido: {sim: '1', nao: '2'},
  };
  const SYN = [['yes', 'si', 'sim', 's'], ['no', 'nao', 'n']];
  const TRANSL = {castanho: ['marrone', 'castani', 'brown', 'marrom'], preto: ['nero', 'neri', 'black'], azul: ['azzurri', 'azzurro', 'blu', 'blue'],
    verde: ['verdi', 'green'], cinza: ['grigi', 'grigio', 'grey', 'gray'], solteiro: ['celibe', 'nubile', 'single'],
    casado: ['coniugat', 'sposat', 'married'], divorciado: ['divorziat', 'divorced'], viuvo: ['vedov', 'widow'], separado: ['separat']};

  function labelOf(e) {
    let t = '';
    if (e.id) { const l = document.querySelector(`label[for="${window.CSS && window.CSS.escape ? window.CSS.escape(e.id) : e.id}"]`); if (l) t = l.innerText; }
    if (!t) { let p = e.closest('.form-group, .row, div'); for (let i = 0; i < 3 && p && !t; i++) { const l = p.querySelector('label'); if (l) t = l.innerText; p = p.parentElement; } }
    return t || e.placeholder || '';
  }
  function classify(label) {
    const l = norm(label);
    for (const [k, ws] of FIELD_RULES) if (ws.some(w => l.includes(w))) return k;
    return null;
  }
  function fire(e) { ['input', 'change', 'blur'].forEach(t => e.dispatchEvent(new Event(t, {bubbles: true}))); }
  function setNative(e, v) {
    const proto = e.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(e, v); fire(e);
  }
  function toISO(s) { const m = String(s).match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/); return m ? `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}` : s; }
  function selectOpt(sel, wanted, key) {
    const w = norm(wanted).replace('/a', '');
    let cands = new Set([w]);
    SYN.forEach(g => { if (g.includes(w)) g.forEach(x => cands.add(x)); });
    Object.entries(TRANSL).forEach(([k, arr]) => { if (w.startsWith(k)) arr.forEach(x => cands.add(x)); });
    const opts = Array.from(sel.options);
    let o = opts.find(o => cands.has(norm(o.text)) || (o.value && norm(o.value) === w));
    if (!o) o = opts.find(o => o.value && [...cands].some(c => c.length >= 3 && norm(o.text).includes(c)));
    if (!o && key && CODES[key]) {
      const code = CODES[key][w] || Object.entries(CODES[key]).find(([k]) => w.includes(k) || k.includes(w))?.[1];
      if (code) o = opts.find(o => o.value === code);
    }
    if (!o) return false;
    sel.value = o.value; fire(sel);
    if (window.jQuery) try { window.jQuery(sel).trigger('change'); } catch (e) {}
    return true;
  }
  function setField(e, value, key) {
    if (!e || value === '' || value == null) return false;
    if (e.tagName === 'SELECT') return selectOpt(e, value, key);
    if (e.type === 'date') { setNative(e, toISO(value)); return true; }
    setNative(e, String(value)); return true;
  }
  function byIdent(ident) {
    return document.getElementById(ident) || document.getElementsByName(ident)[0] || null;
  }

  async function attachDocs() {
    const inputs = $$('input[type=file]');
    const ds = docs();
    for (let i = 0; i < inputs.length && i < ds.length; i++) {
      try {
        const blob = await (await fetch(ds[i].dataUrl)).blob();
        const file = new File([blob], ds[i].nome, {type: ds[i].tipo});
        const dt = new DataTransfer(); dt.items.add(file);
        inputs[i].files = dt.files; fire(inputs[i]);
        log('Anexado: ' + ds[i].nome);
      } catch (e) { log('Falha ao anexar ' + ds[i].nome + ': ' + e); }
    }
    if (inputs.length > ds.length) log(`O site pede ${inputs.length} anexo(s) e você cadastrou ${ds.length}.`);
  }

  async function fillCompanions(list) {
    const num = $('#ddlnumberofcompanions');
    if (!num) return;
    num.value = String(list.length); fire(num);
    if (window.jQuery) try { window.jQuery(num).trigger('change'); } catch (e) {}
    await sleep(2500);
    list.forEach((p, i) => {
      setField(byIdent(`Accompagnatori[${i}].CognomeAccompagnatore`), p.sobrenome);
      setField(byIdent(`Accompagnatori[${i}].NomeAccompagnatore`), p.nome);
      setField(byIdent(`Accompagnatori[${i}].DataNascitaAccompagnatore`), p.nascimento);
      const rel = $('#TypeOfRelationDDL' + i); if (rel) selectOpt(rel, p.parentesco || '');
    });
  }

  function missingRequired() {
    const miss = [];
    $$('form select, form input, form textarea').forEach(e => {
      const t = (e.type || '').toLowerCase();
      if (['hidden', 'submit', 'button'].includes(t) || e.disabled) return;
      if (!visible(e) && t !== 'file') return;
      const lab = labelOf(e);
      const req = e.required || e.getAttribute('aria-required') === 'true' || e.getAttribute('data-val-required') || /\*\s*$/.test(lab.trim());
      if (!req || e.id === 'otp-input') return;
      const empty = t === 'checkbox' ? !e.checked : t === 'file' ? !(e.files && e.files.length) : !String(e.value || '').trim();
      if (empty) { e.style.outline = '3px solid #e53935'; miss.push((lab || e.name || e.id).replace(/\s+/g, ' ').trim().slice(0, 50)); }
    });
    return miss;
  }

  async function fillForm(sid) {
    const c = cfg(), d = c.dados, filled = new Set();
    const tipo = $('#typeofbookingddl');
    if (tipo) { tipo.value = c.acompanhantes.length ? '2' : '1'; fire(tipo); if (window.jQuery) try { window.jQuery(tipo).trigger('change'); } catch (e) {} await sleep(1200); }
    if (c.acompanhantes.length) await fillCompanions(c.acompanhantes);
    const learned = c.respostas_aprendidas || {};
    const unknown = [];
    for (const e of $$('form select, form input, form textarea')) {
      const t = (e.type || e.tagName).toLowerCase();
      if (['hidden', 'submit', 'button', 'checkbox', 'radio', 'file'].includes(t)) continue;
      const ident = e.id || e.name;
      if (!ident || /accompagnatori|typeofbookingddl|ddlnumberofcompanions|otp-input|typeofrelation/i.test(ident)) continue;
      const lab = labelOf(e), key = classify(lab);
      if (key && d[key]) { if (setField(e, d[key], key)) { filled.add(e.id); filled.add(e.name); log('Preenchido: ' + lab.slice(0, 40)); } }
      else if (!key && learned[norm(lab)]) { setField(e, learned[norm(lab)]); filled.add(e.id); filled.add(e.name); }
      else if (!key && norm(lab)) unknown.push({e, lab});
      await sleep(rand(120, 350));
    }
    for (const [ident, key] of Object.entries(PRESETS[sid] || {})) {
      if (filled.has(ident)) continue;
      const e = byIdent(ident);
      if (e && d[key]) setField(e, d[key], key);
    }
    const notes = $('#BookingNotes'); if (notes && d.observacoes) setNative(notes, d.observacoes);
    await attachDocs();
    const priv = $('#PrivacyCheck'); if (priv && !priv.checked) priv.click();
    store.set('pendentes', unknown.map(u => ({id: u.e.id, name: u.e.name, lab: u.lab})));
  }

  function learnAnswers() {
    const pend = store.get('pendentes', []);
    if (!pend.length) return;
    const c = cfg(); let n = 0;
    pend.forEach(p => {
      const e = byIdent(p.id) || byIdent(p.name); if (!e) return;
      const v = e.tagName === 'SELECT' ? (e.value ? e.options[e.selectedIndex].text.trim() : '') : String(e.value || '').trim();
      if (v) { c.respostas_aprendidas[norm(p.lab)] = v; n++; }
    });
    if (n) { saveCfg(c); log(`Aprendi ${n} resposta(s) nova(s) para a próxima vez.`); }
  }

  // ------------------------------------------------------------------ calendario automatico
  async function autoSchedule() {
    const c = cfg();
    const minD = toISO(c.data_min || ''), maxD = toISO(c.data_max || ''), period = c.periodo;
    const okPeriod = s => period === 'manha' ? s.OrarioInizioFascia.Hours < 12 : period === 'tarde' ? s.OrarioInizioFascia.Hours >= 12 : true;
    const post = async (url, body) => {
      const r = await fetch(url, {method: 'POST', credentials: 'same-origin',
        headers: {'Content-Type': 'application/json; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest'}, body: JSON.stringify(body)});
      const t = await r.text(); try { let j = JSON.parse(t); if (typeof j === 'string') j = JSON.parse(j); return j; } catch (e) { return t; }
    };
    let inp = null;
    for (let i = 0; i < 30 && !(inp && inp.value); i++) { inp = $('input#idServizio'); await sleep(1000); }
    if (!inp || !inp.value) return {ok: false, motivo: 'idServizio não encontrado'};
    const sid = inp.value;
    for (let m = 0; m < (+c.meses || 4); m++) {
      const dt = new Date(); dt.setDate(1); dt.setMonth(dt.getMonth() + m); dt.setDate(28);
      let days = await post('/BookingCalendar/RetrieveCalendarAvailability', {_Servizio: sid, selectedDay: dt.toISOString()});
      if (!Array.isArray(days)) days = [];
      days = days.filter(x => x.SlotRimanenti > 0).map(x => ({...x, iso: x.DateLibere.split(' ')[0].split('/').reverse().join('-')}))
        .filter(x => (!minD || x.iso >= minD) && (!maxD || x.iso <= maxD)).sort((a, b) => a.iso.localeCompare(b.iso));
      for (const day of days) {
        let slots = await post('/BookingCalendar/RetrieveTimeSlots', {selectedDay: day.iso, idService: sid});
        if (!Array.isArray(slots)) slots = [];
        slots = slots.filter(x => x.SlotRimanenti > 0);
        slots = [...slots.filter(okPeriod), ...slots.filter(x => !okPeriod(x))];
        for (const s of slots) {
          const p = n => String(n).padStart(2, '0');
          const hr = `${p(s.OrarioInizioFascia.Hours)}:${p(s.OrarioInizioFascia.Minutes)} - ${p(s.OrarioFineFascia.Hours)}:${p(s.OrarioFineFascia.Minutes)}\n(${s.SlotLiberi})`;
          banner(`Tentando ${day.iso.split('-').reverse().join('/')} ${hr.split('\n')[0]}...`, 'alert');
          const res = await post('/BookingCalendar/InsertNewBooking', {idCalendarioGiornaliero: s.IDCalendarioServizioGiornaliero, selectedDay: day.iso, selectedHour: hr});
          if (res && res.url && res.url.includes('/ReservationDetail/')) return {ok: true, url: res.url, dia: day.iso, hora: hr.split('\n')[0]};
        }
      }
    }
    return {ok: false, motivo: 'nenhum horário livre na faixa escolhida'};
  }

  // ------------------------------------------------------------------ comprovante
  function saveProof() {
    try {
      const html = '<!doctype html><meta charset="utf-8">' + document.documentElement.outerHTML;
      const a = el('a', {href: URL.createObjectURL(new Blob([html], {type: 'text/html'})),
        download: 'comprovante_prenotami_' + new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-') + '.html'});
      document.body.appendChild(a); a.click(); a.remove();
      log('Comprovante salvo em Downloads (HTML). Use também Menu > Compartilhar > Imprimir para gerar PDF.');
    } catch (e) { log('Não consegui salvar o comprovante: ' + e); }
  }

  // ------------------------------------------------------------------ ciclo principal
  let timer = null;
  function nextBookingUrl() {
    const list = serviceList();
    const i = (store.get('idx', 0) || 0) % list.length;
    store.set('idx', i + 1);
    store.set('svc_atual', list[i]);
    return `${SITE}/Services/Booking/${list[i]}`;
  }
  function waitAndGo(url, sec, msg) {
    clearInterval(timer);
    let left = Math.round(sec);
    banner(`${msg} Nova verificação em ${left}s`);
    timer = setInterval(() => {
      if (!running()) { clearInterval(timer); banner(''); return; }
      left--;
      banner(`${msg} Nova verificação em ${left}s`);
      if (left <= 0) { clearInterval(timer); location.href = url; }
    }, 1000);
  }
  function pageState() {
    const body = norm(document.body ? document.body.innerText : '');
    if (host().includes('perfdrive') || /captcha/i.test(document.title)) return 'captcha';
    if (path().startsWith('/error')) return 'bloqueado';
    if (path().includes('/reservationdetail')) return 'reservado';
    if (path().includes('/bookingcalendar')) return 'calendario';
    if ($('#typeofbookingddl') || $('#PrivacyCheck') || $('#btnAvanti')) return 'disponivel';
    const dlg = $$("div[role=dialog], .jconfirm-box, .modal.show").find(visible);
    if (dlg || ['non ci sono date disponibili', 'all appointments for this service are currently booked', 'stante l\'elevata richiesta',
      'nao ha datas disponiveis', 'no hay citas disponibles'].some(h => body.includes(h))) return 'indisponivel';
    if ($('#login-email') || $('#pingid-button')) return 'deslogado';
    return 'outro';
  }

  async function iamLogin() {
    const c = cfg();
    if (!c.auto_login || !c.email || !c.senha) { banner('Faça o login para continuar.', 'alert'); return; }
    for (let i = 0; i < 20; i++) {
      const u = $("input[autocomplete='username'], input[type='email'], input[name='username'], input#username");
      const pw = $("input[type='password']");
      const btn = $("button[type='submit'], input[type='submit']");
      if (u && !u.value) { setNative(u, c.email); await sleep(rand(400, 900)); }
      if (pw && !pw.value) { setNative(pw, c.senha); await sleep(rand(500, 1000)); }
      if (u && pw && btn) { btn.click(); log('Login enviado.'); return; }
      if (u && !pw && btn && u.value) { btn.click(); await sleep(2500); continue; }
      await sleep(1000);
    }
    banner('Não encontrei os campos de login - entre manualmente.', 'alert');
  }

  async function tick() {
    if (!running()) return;
    const c = cfg();
    if (host().includes('iam.esteri.it')) { banner('Entrando na sua conta...'); return iamLogin(); }
    let st = pageState();
    // espera a pagina "decidir" (o aviso de sem vagas aparece alguns segundos depois)
    for (let i = 0; i < 12 && (st === 'outro') && path().includes('/services/booking/'); i++) { await sleep(1000); st = pageState(); }
    const sid = store.get('svc_atual', serviceList()[0]);
    const wait = rand(+c.intervalo_min || 45, +c.intervalo_max || 90);

    if (st === 'captcha') {
      alarm('Captcha na tela! Resolva para o bot continuar.', false);
      return;
    }
    if (st === 'bloqueado') {
      log('Site bloqueou temporariamente. Aguardando...');
      return waitAndGo(SITE + '/', (+c.espera_bloqueio_min || 10) * 60, 'Bloqueio temporário do site.');
    }
    if (st === 'deslogado') {
      if (!c.auto_login) { banner('Faça o login para continuar.', 'alert'); return; }
      banner('Entrando na sua conta...');
      const old = $('#login-email');
      if (old) { setNative(old, c.email); setNative($('#login-password'), c.senha); await sleep(800); ($("button[type='submit']") || {}).click?.(); return; }
      $('#pingid-button').click();
      return;
    }
    if (st === 'reservado') {
      setRunning(false); refreshFab();
      alarm('AGENDAMENTO CONFIRMADO! Confira os detalhes na tela e no seu e-mail.');
      await sleep(3000); saveProof();
      return;
    }
    if (st === 'calendario') {
      alarm('CALENDÁRIO ABERTO! Procurando data e horário...');
      if (!c.auto_agendar || c.somente_alertar) { banner('Escolha a data e o horário e confirme.', 'alert'); return; }
      const r = await autoSchedule();
      if (r.ok) { log(`Agendado: ${r.dia} ${r.hora}`); location.href = r.url.startsWith('/') ? SITE + r.url : r.url; }
      else { alarm('Escolha a data manualmente: ' + r.motivo); }
      return;
    }
    if (st === 'disponivel') {
      store.set('tentativas', (store.get('tentativas', 0) || 0) + 1);
      alarm(`VAGA ABERTA no serviço ${sid}! ${c.somente_alertar ? 'Preencha agora!' : 'Preenchendo...'}`);
      if (c.somente_alertar || !c.preencher) return;
      await fillForm(+sid);
      const send = $('#otp-send'), box = $('#otp-input');
      if (send) { send.click(); log('Código OTP solicitado - veja seu e-mail.'); notify('PrenotaBot: código enviado para o seu e-mail. Digite no site!', false); }
      const miss = missingRequired();
      if (miss.length) { alarm(`Complete ${miss.length} campo(s) em vermelho: ${miss.slice(0, 4).join('; ')}`, false); }
      if (box) {
        banner('Digite o código de 6 números que chegou no seu e-mail.', 'alert');
        beep(3);
        for (let i = 0; i < 600 && running(); i++) {  // ate 10 min
          await sleep(1000);
          if (String(box.value || '').replace(/\D/g, '').length >= 6 && !missingRequired().length) break;
        }
      } else if (miss.length) {
        for (let i = 0; i < 600 && running() && missingRequired().length; i++) await sleep(1000);
      }
      learnAnswers();
      if (c.clicar_avancar && running()) {
        const b = $('#btnAvanti');
        if (b) { b.scrollIntoView({block: 'center'}); await sleep(600); b.click(); log('Formulário enviado (Avanti).'); }
      }
      return;
    }
    if (st === 'indisponivel') {
      store.set('tentativas', (store.get('tentativas', 0) || 0) + 1);
      const dlgBtn = $$("div[role=dialog] button, .jconfirm-box button, .modal.show button").find(visible);
      if (dlgBtn) dlgBtn.click();
      log(`Sem vagas no serviço ${sid}.`);
      return waitAndGo(nextBookingUrl(), wait, `Sem vagas (${store.get('tentativas', 0)} tentativas).`);
    }
    // qualquer outra pagina logada: vai para o servico
    if (host().includes('prenotami')) {
      return waitAndGo(nextBookingUrl(), path().includes('/services/booking/') ? wait : 3, 'Indo para o serviço.');
    }
  }

  // mantem a tela acesa enquanto monitora (quando o navegador permite)
  async function keepAwake() {
    try { if (running() && navigator.wakeLock) await navigator.wakeLock.request('screen'); } catch (e) {}
  }
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') keepAwake(); });

  function boot() {
    if (!document.body) return setTimeout(boot, 300);
    buildUI();
    keepAwake();
    if (running()) setTimeout(tick, 1500);
  }
  boot();
})();
